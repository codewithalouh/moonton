const popupContainer = document.querySelector(".popup");
const  popupButton = document.querySelector(".popup-btn");
const  popupButton1 = document.querySelector(".popup-btn1");
const  popupButton2 = document.querySelector(".popup-btn2");
const  popupButton3 = document.querySelector(".popup-btn3");
const  popupButton4 = document.querySelector(".popup-btn4");
const  popupButton5 = document.querySelector(".popup-btn5");
const  popupButton6 = document.querySelector(".popup-btn6");
const  popupButton7 = document.querySelector(".popup-btn7");
const  popupButton8 = document.querySelector(".popup-btn8");
const  popupButton9 = document.querySelector(".popup-btn9");
const  popupButton10 = document.querySelector(".popup-btn10");
const  popupButton11 = document.querySelector(".popup-btn11");
const  popupButton12 = document.querySelector(".popup-btn12");
const  popupButton13 = document.querySelector(".popup-btn13");
const  popupButton14 = document.querySelector(".popup-btn14");



popupButton.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton1.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton2.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton3.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton4.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton5.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton6.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton7.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton8.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton9.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton10.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton11.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton12.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton13.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})

popupButton14.addEventListener("click", () => {
    popupContainer.classList.add("active");
    bodyOp.classList.remove("active");
})



